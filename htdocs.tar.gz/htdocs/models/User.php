<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property int $role_id
 * @property string $username
 * @property string $password
 * @property string $first_name
 * @property string $last_name
 * @property string $middle_name
 *
 * @property Documents[] $documents
 * @property Documents[] $documents0
 * @property Role $role
 */
class User extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username', 'password', 'first_name', 'last_name', 'middle_name'], 'required'],
            [['role_id'], 'integer'],
            [['username', 'password', 'first_name', 'last_name', 'middle_name'], 'string', 'max' => 255],
            [['username'], 'unique'],
            [['role_id'], 'exist', 'skipOnError' => true, 'targetClass' => Role::class, 'targetAttribute' => ['role_id' => 'id']],
            ['role_id', 'default', 'value' => 1],
            [['password'], 'string', 'min' => 6],
            [['first_name', 'last_name', 'middle_name'], 'match', 'pattern' => '/^[а-яА-Я ]*$/u'],
            [['user_photo'], 'file', 'extensions' => 'jpg, jpeg, png, gif', 'maxSize' => 16 * 1024 * 1024, 'mimeTypes' => 'image/jpeg, image/png, image/gif'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'role_id' => 'Role ID',
            'username' => 'Логин',
            'password' => 'Пароль',
            'first_name' => 'Имя',
            'last_name' => 'Фамилия',
            'middle_name' => 'Отчество',
            'user_photo' => 'Фотография',
        ];
    }

    /**
     * Gets query for [[Documents]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDocuments()
    {
        return $this->hasMany(Documents::class, ['user_id' => 'id']);
    }

    /**
     * Gets query for [[Documents0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDocuments0()
    {
        return $this->hasMany(Documents::class, ['created_by' => 'id']);
    }

    /**
     * Gets query for [[Role]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRole()
    {
        return $this->hasOne(Role::class, ['id' => 'role_id']);
    }

        /**
     * {@inheritdoc}
     */
    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        return null;
    }

    /**
     * Finds user by username
     *
     * @param string $username
     * @return static|null
     */
    public static function findByUsername($username)
    {
        return User::findOne(['username' => $username]);
    }

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        return null;
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        return false;
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */

     public function BeforeSave($insert)
     {
         $this->password = ($this->password);
         return parent::BeforeSave($insert);
     }
     

    public function validatePassword($password)
    {
        return $this->password === ($password);
    }

    public function getPhotoUrl()
    {
        return $this->user_photo ? 'data:image/jpeg;base64,' . base64_encode($this->user_photo) : null;
    }
}
