<?php

namespace app\models;
use yii\db\ActiveRecord;

use Yii;

/**
 * This is the model class for table "documents".
 *
 * @property int $id
 * @property int $user_id
 * @property string $first_name
 * @property string $last_name
 * @property string $middle_name
 * @property string $study_form
 * @property int $order_number
 * @property string $order_date
 * @property string $issue_date
 * @property int $document_number
 *
 * @property User $createdBy
 * @property User $user
 */
class Documents extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'documents';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['user_id', 'first_name', 'last_name', 'middle_name', 'study_form', 'order_number', 'order_date', 'issue_date', 'document_number'], 'required'],
            [['user_id', 'document_number'], 'integer'],
            [['order_date', 'issue_date'], 'safe'],
            [['order_date', 'issue_date'], 'date', 'format' => 'php:Y-m-d'],
            [['first_name', 'last_name', 'middle_name', 'study_form'], 'string', 'max' => 255],
            [['document_number'], 'unique'],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['user_id' => 'id']],
            [['user_id'], 'default', 'value' => Yii::$app->user->identity->id],
            [['user_photo'], 'file', 'extensions' => 'jpg, jpeg, png, gif', 'maxSize' => 16 * 1024 * 1024, 'mimeTypes' => 'image/jpeg, image/png, image/gif'],
            [['user_photo'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'ID студента',
            'first_name' => 'Имя',
            'last_name' => 'Фамилия',
            'middle_name' => 'Отчество',
            'study_form' => 'Форма обучения',
            'order_number' => 'Номер приказа',
            'order_date' => 'Дата приказа',
            'issue_date' => 'Дата выдачи',
            'document_number' => 'Номер билета',
            'user_photo' => 'Фотография',
        ];
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::class, ['id' => 'user_id']);
    }

    public $user_photo;

    public function getPhoto()
    {
        return $this->user_photo ? 'data:image/jpeg;base64,' . base64_encode($this->user_photo) : null;
    }
}


