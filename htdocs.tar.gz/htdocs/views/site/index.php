<?php

/** @var yii\web\View $this */

$this->title = 'Люберецкий техникум - Студенческие билеты';
?>
<div class="site-index">

    <div class="jumbotron text-center bg-transparent mt-5 mb-5">
        <h1 class="display-4">Добро пожаловать!</h1>

        <p class="lead">
            Раздел сайта ГБПОУ МО "Люберецкий техникум имени Героя Советского Союза, лётчика-космонавта Ю.А. Гагарина", 
            посвящён автоматическому заполнению документа: Студенческий билет.
        </p>

        <p>
            На данном сайте студенты могут зарегистрироваться и посмотреть свой студенческий билет, 
            а преподаватели — заполнить их.
        </p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-6 mb-3">
                <h2>Для чего нужен студенческий билет?</h2>
                <p>
                    Студенческий билет — это официальный документ, удостоверяющий статус обучающегося. 
                    Он необходим для получения скидок в общественном транспорте, посещения библиотек, а также 
                    других образовательных и социальных учреждений. Студенческий билет подтверждает право 
                    студента на льготы, предусмотренные законодательством.
                </p>
            </div>

            <div class="col-lg-6" style="display: flex; align-items: center;">
                <img src="../media/web-developer.jpg" alt="Веб-разработчик" class="img-fluid rounded shadow" style="width: 250px; height: auto; margin-right: 10px;">
                <img src="../media/graph-developer.png" alt="Графический дизайнер" class="img-fluid rounded shadow" style="width: 300px; height: auto;">
            </div>
        </div>

        <hr class="my-5">

            <div class="row justify-content-center">
                <div class="col-lg-4 mb-3 text-center">
                    <h2>Регистрация</h2>
                    <p>
                        Для использования функционала сайта зарегистрируйтесь. После регистрации студенты могут 
                        просматривать свой студенческий билет, а преподаватели — добавлять их.
                    </p>
                    <p><a class="btn btn-outline-primary btn-lg" href="/user/create">Зарегистрироваться</a></p>
                </div>
                <div class="col-lg-4 mb-3 text-center">
                    <h2>Авторизация</h2>
                <p>
                    Если вы уже зарегистрированы, войдите в свою учётную запись, чтобы получить доступ к функционалу сайта.
                    </p>
                    <p><a class="btn btn-outline-primary btn-lg" href="/site/login">Войти</a></p>
                </div>
            </div>

    </div>
</div>