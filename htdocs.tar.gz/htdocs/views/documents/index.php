<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\Documents[] $documents */

if (Yii::$app->user->identity->role_id == 2) { // Преподаватель
   $this->title = 'Студенческие билеты';
} else { // Студент
   $this->title = 'Студенческий билет';
}
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="documents-index">
   <h1><?= Html::encode($this->title) ?></h1>

   <?php if (Yii::$app->user->identity->role_id == 1): ?>
       <p>
           <!-- Форма для загрузки фотографии -->
           <?php $form = ActiveForm::begin(['action' => ['upload-photo'], 'options' => ['enctype' => 'multipart/form-data']]); ?>

           <?= $form->field(Yii::$app->user->identity, 'user_photo')->fileInput() ?>

           <button type="submit" class="btn btn-outline-primary btn-lg">Загрузить фотографию</button>

           <?php ActiveForm::end(); ?>
       </p>
   <?php endif; ?>

   <?php if (Yii::$app->user->identity->role_id == 2): ?>
        <p>
            <?= Html::a('Создать студенческий билет', ['create'], ['class' => 'btn btn-outline-primary btn-lg']) ?>
        </p>
    <?php endif; ?>

   <?php if (empty($documents)): ?>
       <p>Студенческого билета пока нет.</p>
    <?php else: ?>
        <?php foreach ($documents as $document): ?>
            <div style="position: relative; width: 1000px; height: 700px; margin: 20px auto; border: 1px solid black; padding: 20px; font-family: Arial, sans-serif;">
                <img src="<?= Html::encode($document->user->getPhotoUrl()) ?>" style="position: absolute; top: 80px; left: 30px; width: 270px; height: 390px; object-fit: cover;" alt="Фотография студента">

                <h4 style="text-align: center; font-weight: bold; margin-left: 300px; font-size: 20px;">
                    Государственное бюджетное профессиональное образовательное учреждение Московской области<br>
                    Люберецкий техникум имени Героя Советского Союза,<br>
                    лётчика – космонавта Ю. А. Гагарина
                </h4>

                <h2 style="text-align: center; margin-top: 40px; margin-left: 180px; font-weight: bold; ">
                    СТУДЕНЧЕСКИЙ БИЛЕТ № <?= Html::encode($document->document_number) ?>
                </h2>

                <p style="font-weight: normal; margin-left: 320px; font-size: 22px;">
                    Фамилия
                    <span style="font-style: italic; text-decoration: underline; margin-left: 100px; font-size: 28px;">
                        <?= Html::encode($document->last_name) ?>
                    </span>
                </p>

                <p style="font-weight: normal; margin-left: 320px; font-size: 22px;">
                    Имя, отчество
                    <span style="font-style: italic; text-decoration: underline; margin-left: 45px; font-size: 28px;">
                    <?= Html::encode($document->first_name) ?> <?= Html::encode($document->middle_name) ?>
                    </span>
                </p>

                <p style="font-weight: normal; margin-left: 320px; font-size: 22px;">
                    Форма обучения
                    <span style="font-style: italic; text-decoration: underline; margin-left: 20px; font-size: 28px;">
                    <?= Html::encode($document->study_form) ?>
                    </span>
                </p>

                <p style="font-weight: normal; margin-left: 320px; font-size: 22px;">
                    Зачислен приказом от
                    <span style="font-style: italic; margin-left: 20px; font-size: 28px;">
                    <?= Yii::$app->formatter->asDate($document->order_date, 'dd.MM.yyyy') ?>г. № <?= Html::encode($document->order_number) ?>
                    </span>
                </p>

                <p style="font-weight: normal; margin-left: 320px; font-size: 22px;">
                    Дата выдачи билета
                    <span style="font-style: italic; text-decoration: underline; margin-left: 5px; font-size: 28px;">
                    <?= Yii::$app->formatter->asDate($document->issue_date, 'dd.MM.yyyy') ?>
                    </span>
                </p>

                <p style="font-weight: bold; font-size: 28px; margin-left: 40px;">
                    М.П.
                </p>

                <p style="position: absolute; left: 630px; bottom: 148px;">
                    _____________________________
                </p>

                <p style="position: absolute; font-weight: bold; font-size: 16px; left: 725px; bottom: 125px;">
                    (подпись студента)
                </p>

                <p style="position: absolute; font-weight: bold; font-size: 16px; margin-left: 40px; bottom: 55px;">
                    Руководитель организации,<br>
                    осуществляющей<br>
                    образовательную<br>
                    деятельность
                </p>

                <p style="position: absolute; left: 220px; bottom: 80px;">
                    ________________________________________
                </p>

                <p style="position: absolute; font-weight: bold; font-size: 16px; left: 220px; bottom: 55px;">
                    (подпись)
                </p>
                
                <p style="position: absolute; font-weight: bold; font-size: 16px; left: 580px; bottom: 78px;">
                    О.А. Клубничкина
                </p>

                <p style="position: absolute; font-weight: bold; font-size: 16px; left: 545px; bottom: 55px;">
                    (фамилия, имя, отчество)
                </p>

            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>


