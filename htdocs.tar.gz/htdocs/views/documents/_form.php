<?php

use yii\helpers\Html;
use yii\bootstrap5\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\User;

/** @var yii\web\View $this */
/** @var app\models\Documents $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="documents-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'user_id')->dropDownList(
        ArrayHelper::map(
            User::find()->where(['!=', 'role_id', 2])->all(), // исключение преподавателей (role_id = 2)
            'id', // тут значение для выбора (ID)
            function ($user) { // текст....
                return "{$user->id} — {$user->last_name} {$user->first_name} {$user->middle_name}";
            }
        ),
        ['prompt' => 'Выберите студента'] // начальный пункт списка
    ) ?>

    <?= $form->field($model, 'first_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'last_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'middle_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'study_form')->dropDownList(
        [
            'Очная' => 'Очная',
            'Заочная' => 'Заочная',
            'Очно-заочная' => 'Очно-заочная',
        ],
        ['prompt' => 'Выберите форму обучения']
    ) ?>

    <?= $form->field($model, 'order_number')->dropDownList(
        [
            '77-у' => '77-у',
        ],
        ['prompt' => 'Выберите номер приказа']
    ) ?>

    <?= $form->field($model, 'order_date')->textInput([
        'type' => 'date',
        'class' => 'form-control',
        'placeholder' => 'Выберите дату',
    ]) ?>

    <?= $form->field($model, 'issue_date')->textInput([
        'type' => 'date',
        'class' => 'form-control',
        'placeholder' => 'Выберите дату',
    ]) ?>

    <?= $form->field($model, 'document_number')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Сохранить', ['class' => 'btn btn-outline-primary btn-lg']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
